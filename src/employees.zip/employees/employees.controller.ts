import { Controller, Get, Post, Body } from '@nestjs/common';
import { EmployeesService } from './employees.service';
import { Employee } from './entities/employee.entity';
import { CreateEmployeeDto } from './dto/create-employee.dto';

@Controller('employees')
export class EmployeesController {
  constructor(private readonly employeesService: EmployeesService) { }

  @Get()
  async findAll(): Promise<Employee[]> {
    return this.employeesService.findAll();
  }

  // NUEVO: Endpoint para crear empleados
  // employees.controller.ts
  @Post()
  async create(@Body() createEmployeeDto: CreateEmployeeDto) {
    console.log('BODY RECIBIDO:', createEmployeeDto);
    return await this.employeesService.create(createEmployeeDto);
  }



}
