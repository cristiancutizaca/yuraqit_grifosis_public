import {
  IsIn,
  IsString,
  MinLength,
  IsOptional,
  IsObject,
  IsBoolean,
  IsInt,
} from 'class-validator';
import { UserPermissions } from '../users.service';

export class CreateUserDto {
  @IsString()
  username: string;

  @MinLength(6)
  password: string;

  @IsString()
  full_name: string;

  @IsIn(['superadmin', 'admin', 'seller'])
  role: string;

  @IsOptional()
  @IsObject()
  permissions?: UserPermissions;

  @IsOptional()
  @IsBoolean()
  is_active?: boolean;

  @IsOptional()
  @IsInt()
  employee_id?: number;
}
